// app.js: faz a Config do servidor Express e define as rotas principais.
const express = require('express');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes');

const app = express();

// Define EJS como o motor de visualização.
app.set('view engine', 'ejs');
// faz a config do body-parser para processar dados de formulários.
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Redireciona as rotas de usuário na aplicação.
app.use('/users', userRoutes);

// Manda a raiz ("/") para "/users"
app.get('/', (req, res) => {
  res.redirect('/users');
});

// Inicia o servidor na porta 3000.
app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
