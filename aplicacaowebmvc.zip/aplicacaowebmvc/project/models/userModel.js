// Model: Responsável pela lógica de negócios e manipulação de dados.
class UserModel {
    constructor() {
                    this.users = []; // Inicializa o array de usuários.
    }

    // Adiciona um novo usuário ao array.
    addUser(user) {
                    this.users.push(user);
    }

    // Retorna todos os usuários.
    getAllUsers() {
                    return this.users;
    }
}

// Exporta uma instância do UserModel para ser usada pelos controllers.
module.exports = new UserModel();
