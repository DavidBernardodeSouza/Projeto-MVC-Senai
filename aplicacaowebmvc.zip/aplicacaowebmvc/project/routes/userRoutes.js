// Routes: Define as rotas da aplicação e associa as rotas aos métodos do controller.
const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

// Caminho de exibir o formulário de cadastro.
router.get('/form', userController.showForm);

// Caminho de adicionar um usuário.
router.post('/add', userController.addUser);

//Caminho de listar todos os usuários.
router.get('/', userController.listUsers);

// Exporta o roteador para ser usado na aplicação principal.
module.exports = router;
