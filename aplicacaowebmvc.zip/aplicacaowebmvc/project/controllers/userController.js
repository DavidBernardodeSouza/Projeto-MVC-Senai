// Controller: Intermediário entre a View e o Model. Processa as requisições e manipula os dados através do Model.
const UserModel = require('../models/userModel');

// Exibe o formulário de cadastro de usuário.
exports.showForm = (req, res) => {
    res.render('userForm');
};

// Adiciona um novo usuário utilizando os dados do formulário.
exports.addUser = (req, res) => {   
                                 const { name, email } = req.body;
                                 UserModel.addUser({ name, email });
                                 res.redirect('/users');
};

// Lista todos os usuários cadastrados.
exports.listUsers = (req, res) => {
                                    const users = UserModel.getAllUsers();
                                    res.render('userList', { users });
};
